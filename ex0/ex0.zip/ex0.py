######################################################################
# FILE: ex0.py
# WRITER: maman, benm, 341145811
# EXERCISE: intro2cs ex0 2017-2018
# A simple program that prints "Hello Wolrd!" to the standard outpout>
#######################################################################

print("Hello World!")